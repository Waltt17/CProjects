// sumMatches.c
#include "sumMatches.h"

/**  Determines which digits of left and right are equal, and occur
 *   at the same positions, and computes the sum of those digits.
 *   
 *   Pre:  left and right are initialized
 *   Returns: sum of matching digits; zero if none occur
 */
int8_t sumMatches(uint32_t left, uint32_t right) {
	
	int8_t sum = -42;
	
	// IMPLEMENT THE LOGIC FOR YOUR SOLUTION HERE
	
	return sum;
}
