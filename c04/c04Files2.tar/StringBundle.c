#include "StringBundle.h"
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

static char* copyOf(const char* const str);
static char* nextField(const char* const Line);

StringBundle* createStringBundle(const char* const str) {
	
   // implement the body of this function
   
   // feel free to change the return statement
	return NULL;
}

void printStringBundle(FILE* fp, const StringBundle* const sb) {
	
	//fprintf(fp, "There are %"PRIu32" tokens:\n", sb->nTokens);
	
	for (uint32_t idx = 0; idx < sb->nTokens; idx++) {
		fprintf(fp, "   %3"PRIu32":  [%s]\n", idx, sb->Tokens[idx]);
	}
}

void clearStringBundle(StringBundle* sb) {
	
   // implement the body of this function
   
}

static char* copyOf(const char* const str) {
	
	char* cpy;
	if ( str == NULL ) {
		cpy = calloc(1, sizeof(char));
		return cpy;
	}
	
	cpy = calloc(sizeof(char), strlen(str) + 1);
	strcpy(cpy, str);
	return cpy;
}

static char* nextField(const char* const Line) {
	
	static const char* currPos = NULL;
	if ( Line != NULL ) {         // reset if given fresh line to parse
		currPos = Line;
	}
	
	char dest[MAX_FIELDLENGTH] = {0};

	char* field = NULL;
	if ( *currPos == '|' ) {
		field = calloc(1, sizeof(char));
		currPos++;
	}
	else if ( sscanf(currPos, "%[^|]|", dest) > 0 )  {
	   field = calloc(1, strlen(dest) + 1);
	   strcpy(field, dest);
      currPos += strlen(dest);
      if ( *currPos != '\0' ) currPos++;
   }
   	
	return field;
}
