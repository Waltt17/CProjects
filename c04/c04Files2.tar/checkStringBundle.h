#ifndef CHECKSTRINGBUNDLE_H
#define CHECKSTRINGBUNDLE_H
#include <stdio.h>
#include <inttypes.h>
#include "StringBundle.h"

uint32_t checkStringBundle(FILE* fp, const StringBundle* const pSB, const char* pStr);

#endif
